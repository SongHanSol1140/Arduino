#ifndef WEB_H
#define WEB_H

void startWebServer();
void handleClientRequests();

#endif // WEB_H
