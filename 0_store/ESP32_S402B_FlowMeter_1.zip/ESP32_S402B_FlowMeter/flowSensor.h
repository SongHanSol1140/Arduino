// flowSensor.h
#ifndef FLOWSENSOR_H
#define FLOWSENSOR_H
#include <Arduino.h>
void IRAM_ATTR pulseCounter();
void calculateFlow();
#endif // FLOWSENSOR_H